	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2024 FixIt </b> Всички права запазени.
		</div>
	</div>