	<div class="col-md-4">
					<!-- checkout-progress-sidebar -->
<div class="checkout-progress-sidebar ">
	<div class="panel-group">
		<div class="panel panel-default">
			<div class="panel-heading">
		    	<h4 class="unicase-checkout-title">Бързи връзки</h4>
		    </div>
		    <div class="panel-body">
				<ul class="nav nav-checkout-progress list-unstyled">
					<li><a href="my-account.php">Моят профил</a></li>
					<li><a href="bill-ship-addresses.php">Адрес за доставка</a></li>
					<li><a href="order-history.php">История на поръчките</a></li>
					<li><a href="pending-orders.php">Чакащи плащания</a></li>
				</ul>		
			</div>
		</div>
	</div>
</div> 
<!-- checkout-progress-sidebar -->				</div>